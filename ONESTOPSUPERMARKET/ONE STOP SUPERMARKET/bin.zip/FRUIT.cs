﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ONE_STOP_SUPERMARKET
{
    public partial class FRUIT : Form
    {
        public FRUIT()
        {
            InitializeComponent();
        }


        private void button_cart_Click(object sender, EventArgs e)
        {
            CART cart = new CART();
            cart.Dock = DockStyle.Fill;
            cart.FormBorderStyle = FormBorderStyle.None;
            cart.TopLevel = false;
            cart.ControlBox = false;
            //this.panel1.Controls.Clear();
            //this.panel1.Controls.Add(cart);
            cart.Show();
        }
    }
}
